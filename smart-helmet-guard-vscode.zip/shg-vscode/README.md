# SMART HELMET GUARD

Single-file app: `index.html` (no install, no build).

**Run in VS Code:** open this folder, right-click `index.html` -> "Open with Live Server" (extension recommended), or just double-click `index.html`.

Go to **Devices** -> add a device (name, ID, Pico W IP, optional control key, location) -> **SELECT** it -> **Connect**.

Requirements: laptop and Pico W on the same Wi-Fi; firmware must send `Access-Control-Allow-Origin: *` on `/api`; do not host on HTTPS (browsers block http:// devices).
